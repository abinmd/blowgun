"""Check the project's coding rules on Python files: every function has a docstring
and no function is longer than 20 lines (from `def` to its last line).

Usage:  python scripts/check_style.py
"""
import ast
import sys
from pathlib import Path

MAX_LINES = 20
FOLDERS = ("app", "scripts", "tests")
ROOT = Path(__file__).resolve().parent.parent


def check_file(path: Path) -> list[str]:
    """Return one message per rule broken in the given Python file."""
    tree = ast.parse(path.read_text(encoding="utf-8"))
    problems = []
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        length = node.end_lineno - node.lineno + 1
        where = f"{path.relative_to(ROOT)}:{node.lineno} {node.name}()"
        if length > MAX_LINES:
            problems.append(f"{where} has {length} lines (max {MAX_LINES})")
        if ast.get_docstring(node) is None:
            problems.append(f"{where} has no docstring")
    return problems


def main() -> int:
    """Check every Python file in the project folders and print the problems found."""
    problems = []
    for folder in FOLDERS:
        for path in sorted((ROOT / folder).rglob("*.py")):
            problems.extend(check_file(path))
    for problem in problems:
        print(problem)
    print(f"{len(problems)} problem(s) found")
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
