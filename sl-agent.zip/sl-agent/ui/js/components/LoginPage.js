// Login page: the user types a username that is listed in users.json.
import { html, useState } from "../lib.js";
import { login } from "../api.js";

/** Login form; calls onLogin(user) when the username is accepted. */
export function LoginPage({ onLogin }) {
  const [username, setUsername] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const submit = (event) => {
    event.preventDefault();
    tryLogin(username, { onLogin, setError, setBusy });
  };
  return html`
    <div className="login-screen">
      <form className="login-card" onSubmit=${submit}>
        <${LoginHeader} />
        <input autoFocus value=${username} placeholder="User name" onChange=${(e) => setUsername(e.target.value)} />
        <button type="submit" disabled=${busy || !username.trim()}>${busy ? "Signing in…" : "Sign in"}</button>
        ${error && html`<p className="error-text">${error}</p>`}
      </form>
    </div>
  `;
}

/** Logo, title and hint at the top of the login card. */
function LoginHeader() {
  return html`
    <div className="login-header">
      <div className="brand-mark">SL</div>
      <h1>SL Agent</h1>
      <p className="muted">Sign in with your user name</p>
    </div>
  `;
}

/** Call the login API and report the user or the error message. */
async function tryLogin(username, { onLogin, setError, setBusy }) {
  setBusy(true);
  setError("");
  try {
    onLogin(await login(username.trim()));
  } catch (error) {
    setError(error.message);
    setBusy(false);
  }
}
