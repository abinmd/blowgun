"""Read agent definitions from the agents folder.

Each agent is two files that share a name:
  agents/<name>.json        -> config: name, description, model, skills, mcp_servers
  agents/<name>-prompt.md   -> system prompt (the role and task of the agent)
"""
import json
import logging
import os
import re
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

PROMPT_SUFFIXES = (".md", ".txt")
VALID_NAME = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
MCP_TYPES = ("stdio", "http", "sse")


class AgentConfigError(ValueError):
    """Raised when an agent config or its prompt file is missing or invalid."""


@dataclass
class McpServerSpec:
    """Connection details for one MCP server used by an agent."""

    name: str
    type: str
    command: str = ""
    args: list[str] = field(default_factory=list)
    env: dict[str, str] = field(default_factory=dict)
    url: str = ""
    headers: dict[str, str] = field(default_factory=dict)
    tool_filter: list[str] | None = None

    def target(self) -> str:
        """Human-readable description of where the server runs (shown in the UI)."""
        if self.type == "stdio":
            return " ".join([self.command, *self.args])
        return self.url


@dataclass
class AgentSpec:
    """Everything needed to build one agent, exactly as read from disk."""

    name: str
    description: str
    model: str
    instruction: str
    skills: list[str] = field(default_factory=list)
    mcp_servers: list[McpServerSpec] = field(default_factory=list)
    config_file: str = ""


def load_agents(folder: Path, default_model: str) -> list[AgentSpec]:
    """Load every valid agent in the folder; broken or duplicate agents are logged and skipped."""
    specs: dict[str, AgentSpec] = {}
    for config_file in sorted(folder.glob("*.json")):
        try:
            spec = load_agent(config_file, default_model)
        except AgentConfigError as error:
            logger.error("Skipping agent file %s: %s", config_file.name, error)
            continue
        # Two files must not claim the same agent name.
        if spec.name in specs:
            logger.error("Skipping %s: agent name '%s' is already used", config_file.name, spec.name)
            continue
        specs[spec.name] = spec
    return list(specs.values())


def load_agent(config_file: Path, default_model: str) -> AgentSpec:
    """Build an AgentSpec from one config file and its matching prompt file."""
    data = _read_json(config_file)
    name = str(data.get("name", config_file.stem))
    _validate_name(name)
    model = str(data.get("model") or default_model)
    if not model:
        raise AgentConfigError("no 'model' set and no default_model in config/bedrock.yml")
    return AgentSpec(
        name=name,
        description=str(data.get("description", "")),
        model=model,
        instruction=_find_prompt_file(config_file).read_text(encoding="utf-8").strip(),
        skills=[str(skill) for skill in data.get("skills", [])],
        mcp_servers=[_parse_mcp_server(item) for item in data.get("mcp_servers", [])],
        config_file=config_file.name,
    )


def _read_json(path: Path) -> dict:
    """Parse a JSON file and make sure it holds an object."""
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as error:
        raise AgentConfigError(f"invalid JSON: {error}") from error
    if not isinstance(data, dict):
        raise AgentConfigError("config must be a JSON object")
    return data


def _validate_name(name: str) -> None:
    """Agent names become ADK identifiers, so only letters, digits and '_' are allowed."""
    if not VALID_NAME.match(name):
        raise AgentConfigError(f"name '{name}' must use only letters, digits and '_'")


def _find_prompt_file(config_file: Path) -> Path:
    """Locate <name>-prompt.md (or .txt) next to the config file."""
    for suffix in PROMPT_SUFFIXES:
        candidate = config_file.with_name(f"{config_file.stem}-prompt{suffix}")
        if candidate.exists():
            return candidate
    raise AgentConfigError(f"missing prompt file {config_file.stem}-prompt.md")


def _parse_mcp_server(item: dict) -> McpServerSpec:
    """Turn one validated entry of 'mcp_servers' into an McpServerSpec."""
    server_type = _validate_mcp_item(item)
    return McpServerSpec(
        name=str(item.get("name", server_type)),
        type=server_type,
        command=str(item.get("command", "")),
        args=[_expand(arg) for arg in item.get("args", [])],
        env=_expand_dict(item.get("env", {})),
        url=_expand(item.get("url", "")),
        headers=_expand_dict(item.get("headers", {})),
        tool_filter=item.get("tool_filter"),
    )


def _validate_mcp_item(item) -> str:
    """Check an MCP entry has what its type needs and return the lower-case type."""
    if not isinstance(item, dict):
        raise AgentConfigError("each mcp_servers entry must be an object")
    server_type = str(item.get("type", "stdio")).lower()
    if server_type not in MCP_TYPES:
        raise AgentConfigError(f"MCP type '{server_type}' must be one of {MCP_TYPES}")
    if server_type == "stdio" and not item.get("command"):
        raise AgentConfigError("a stdio MCP server needs a 'command'")
    if server_type != "stdio" and not item.get("url"):
        raise AgentConfigError(f"a {server_type} MCP server needs a 'url'")
    return server_type


def _expand(value) -> str:
    """Replace ${VAR} references with environment values so secrets stay out of config files."""
    return os.path.expandvars(str(value))


def _expand_dict(values: dict) -> dict[str, str]:
    """Expand ${VAR} references in every value of a dict."""
    return {str(key): _expand(value) for key, value in values.items()}
