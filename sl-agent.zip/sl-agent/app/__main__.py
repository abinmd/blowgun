"""Allow `python -m app` to start the server (HOST / PORT env vars are optional)."""
import os

import uvicorn


def main() -> None:
    """Start uvicorn serving both the API and the UI."""
    host = os.getenv("HOST", "127.0.0.1")
    port = int(os.getenv("PORT", "8000"))
    uvicorn.run("app.main:app", host=host, port=port)


if __name__ == "__main__":
    main()
