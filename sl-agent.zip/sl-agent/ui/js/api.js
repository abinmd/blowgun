// Thin wrappers around the backend API. The logged-in username travels in X-Username.
let currentUsername = "";

/** Remember who is logged in so every request carries the X-Username header. */
export function setApiUser(username) {
  currentUsername = username || "";
}

/** Headers sent with every JSON request. */
function headers() {
  return { "Content-Type": "application/json", "X-Username": currentUsername };
}

/** Turn FastAPI's "detail" (a string or a list of validation errors) into one message. */
function formatDetail(detail) {
  if (Array.isArray(detail)) return detail.map((item) => item.msg).join(", ");
  return detail || "";
}

/** Build an Error carrying the server's message from a failed response. */
async function toError(response) {
  const fallback = response.statusText || `HTTP ${response.status}`;
  try {
    const body = await response.json();
    return new Error(formatDetail(body.detail) || fallback);
  } catch {
    return new Error(fallback);
  }
}

/** Send a JSON request and return the parsed JSON response. */
async function request(method, path, body) {
  const options = { method, headers: headers() };
  if (body !== undefined) options.body = JSON.stringify(body);
  const response = await fetch(path, options);
  if (!response.ok) throw await toError(response);
  return response.json();
}

/** Log in with a username from users.json. */
export const login = (username) => request("POST", "/api/login", { username });

/** Agents the logged-in user may choose. */
export const listAgents = () => request("GET", "/api/agents");

/** Start a fresh chat session with an agent. */
export const startSession = (agent) => request("POST", "/api/sessions", { agent });

/** Send a chat message and call onEvent for every trace event streamed back (NDJSON). */
export async function streamChat(body, onEvent) {
  const response = await fetch("/api/chat", { method: "POST", headers: headers(), body: JSON.stringify(body) });
  if (!response.ok) throw await toError(response);
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer = emitLines(buffer + decoder.decode(value, { stream: true }), onEvent);
  }
  emitLines(buffer + "\n", onEvent);
}

/** Emit every complete line in the buffer as an event; return the unfinished remainder. */
function emitLines(buffer, onEvent) {
  const lines = buffer.split("\n");
  const rest = lines.pop();
  for (const line of lines) {
    if (line.trim()) onEvent(JSON.parse(line));
  }
  return rest;
}
