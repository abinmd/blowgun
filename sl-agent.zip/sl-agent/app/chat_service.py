"""Run chat turns through ADK and turn each ADK event into a simple trace event for the UI.

Trace event types: session_started, user_message, model_usage, tool_call, tool_result,
thought, agent_message (final=True is the answer shown in the chat), error, turn_complete.
Every trace event is also written to the agent action log.
"""
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import AsyncIterator

from google.genai import types

from .action_logger import log_action
from .agent_registry import LoadedAgent
from .users import User


@dataclass
class TurnContext:
    """Who is talking to which agent in which session (attached to every trace event)."""

    user_id: str
    username: str
    agent: str
    session_id: str

    def event(self, payload: dict) -> dict:
        """Stamp a trace event with time and context, write it to the action log and return it."""
        event = {
            "time": datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
            "user_id": self.user_id,
            "username": self.username,
            "agent": self.agent,
            "session_id": self.session_id,
            **payload,
        }
        log_action(event)
        return event


async def start_session(loaded: LoadedAgent, user: User) -> dict:
    """Create a fresh ADK session (a clean chat) and return its 'session_started' event."""
    session = await loaded.runner.session_service.create_session(
        app_name=loaded.spec.name, user_id=user.user_id
    )
    context = TurnContext(user.user_id, user.username, loaded.spec.name, session.id)
    return context.event({"type": "session_started", "model": loaded.spec.model})


async def session_exists(loaded: LoadedAgent, user: User, session_id: str) -> bool:
    """Check that the session exists and belongs to this user and agent."""
    session = await loaded.runner.session_service.get_session(
        app_name=loaded.spec.name, user_id=user.user_id, session_id=session_id
    )
    return session is not None


async def stream_chat(
    loaded: LoadedAgent, user: User, session_id: str, message: str
) -> AsyncIterator[dict]:
    """Send one user message to the agent and yield trace events while the agent works."""
    context = TurnContext(user.user_id, user.username, loaded.spec.name, session_id)
    started = time.perf_counter()
    yield context.event({"type": "user_message", "text": message})
    content = types.Content(role="user", parts=[types.Part(text=message)])
    events = loaded.runner.run_async(user_id=user.user_id, session_id=session_id, new_message=content)
    try:
        async for adk_event in events:
            for payload in translate_event(adk_event, loaded):
                yield context.event(payload)
    except Exception as error:  # model or tool failures are reported to the UI, not raised
        yield context.event({"type": "error", "message": friendly_error(error)})
    elapsed_ms = round((time.perf_counter() - started) * 1000)
    yield context.event({"type": "turn_complete", "duration_ms": elapsed_ms})


def friendly_error(error: Exception) -> str:
    """Error text for the UI, with a hint when the AWS credentials have expired."""
    message = str(error) or type(error).__name__
    lowered = message.lower()
    if "expired" in lowered and "token" in lowered:
        return f"{message}\n\nThe AWS session token has expired: paste fresh credentials into config/bedrock.yml (no restart needed)."
    return message


def translate_event(adk_event, loaded: LoadedAgent) -> list[dict]:
    """Convert one ADK event into zero or more trace events."""
    payloads = _usage_payload(adk_event)
    parts = []
    if adk_event.content and adk_event.content.parts:
        parts = adk_event.content.parts
    for part in parts:
        payload = _translate_part(part, adk_event, loaded)
        if payload:
            payloads.append(payload)
    return payloads


def _translate_part(part, adk_event, loaded: LoadedAgent) -> dict | None:
    """Map one content part to a trace event: tool call, tool result, thought or agent text."""
    author = adk_event.author
    if part.function_call:
        call = part.function_call
        source = loaded.tool_source(call.name)
        return {"type": "tool_call", "author": author, "tool": call.name, "source": source, "args": call.args or {}}
    if part.function_response:
        reply = part.function_response
        source = loaded.tool_source(reply.name)
        return {"type": "tool_result", "author": author, "tool": reply.name, "source": source, "result": reply.response}
    if part.text and part.thought:
        return {"type": "thought", "author": author, "text": part.text}
    if part.text:
        return {"type": "agent_message", "author": author, "text": part.text, "final": adk_event.is_final_response()}
    return None


def _usage_payload(adk_event) -> list[dict]:
    """Report the token usage of an LLM call when ADK provides it."""
    usage = getattr(adk_event, "usage_metadata", None)
    if usage is None or not usage.total_token_count:
        return []
    return [{
        "type": "model_usage",
        "author": adk_event.author,
        "prompt_tokens": usage.prompt_token_count or 0,
        "output_tokens": usage.candidates_token_count or 0,
        "total_tokens": usage.total_token_count,
    }]
