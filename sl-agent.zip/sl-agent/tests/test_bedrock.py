"""Tests for config/bedrock.yml handling (no AWS calls are made)."""
import json
import os
import tempfile
import unittest
import unittest.mock
from pathlib import Path

import yaml

from app.agent_loader import AgentConfigError, load_agent
from app.bedrock import BedrockSettings


def write_config(path: Path, data: dict, mtime: float) -> None:
    """Write a Bedrock config and force its modified time (so changes are always detected)."""
    path.write_text(yaml.safe_dump(data), encoding="utf-8")
    os.utime(path, (mtime, mtime))


class BedrockSettingsTests(unittest.TestCase):
    """Reading, expanding and reloading the Bedrock config."""

    def setUp(self):
        """Each test gets a temporary config path."""
        self._tmp = tempfile.TemporaryDirectory()
        self.path = Path(self._tmp.name) / "bedrock.yml"

    def tearDown(self):
        """Remove the temporary folder."""
        self._tmp.cleanup()

    def test_missing_file_is_not_loaded(self):
        """No file: nothing loaded and no credentials passed on."""
        settings = BedrockSettings(self.path)
        self.assertFalse(settings.reload_if_changed())
        self.assertFalse(settings.is_loaded())
        self.assertEqual(settings.litellm_args(), {})

    def test_credentials_become_litellm_args(self):
        """Keys map to LiteLLM argument names; empty values are left out."""
        data = {"region": "us-east-1", "access_key_id": "AK", "secret_access_key": "SK",
                "session_token": "ST", "profile": "", "default_model": "bedrock/x"}
        write_config(self.path, data, 1000)
        settings = BedrockSettings(self.path)
        self.assertTrue(settings.reload_if_changed())
        expected = {"aws_region_name": "us-east-1", "aws_access_key_id": "AK",
                    "aws_secret_access_key": "SK", "aws_session_token": "ST"}
        self.assertEqual(settings.litellm_args(), expected)
        self.assertEqual(settings.default_model(), "bedrock/x")

    def test_env_variables_are_expanded(self):
        """${VAR} values come from the environment; unset variables count as empty."""
        write_config(self.path, {"session_token": "${SL_TOKEN}", "access_key_id": "${SL_UNSET}"}, 1000)
        settings = BedrockSettings(self.path)
        with unittest.mock.patch.dict("os.environ", {"SL_TOKEN": "from-env"}):
            settings.reload_if_changed()
            self.assertEqual(settings.litellm_args(), {"aws_session_token": "from-env"})

    def test_reload_only_when_file_changes(self):
        """A new session token is picked up; an unchanged or broken file keeps the old values."""
        write_config(self.path, {"session_token": "old"}, 1000)
        settings = BedrockSettings(self.path)
        settings.reload_if_changed()
        self.assertFalse(settings.reload_if_changed())
        write_config(self.path, {"session_token": "new"}, 2000)
        self.assertTrue(settings.reload_if_changed())
        self.path.write_text("region: [unclosed", encoding="utf-8")
        os.utime(self.path, (3000, 3000))
        self.assertFalse(settings.reload_if_changed())
        self.assertEqual(settings.litellm_args()["aws_session_token"], "new")

    def test_example_file_parses(self):
        """The shipped example YAML loads and gives a Bedrock default model."""
        settings = BedrockSettings(Path(__file__).parent.parent / "config" / "bedrock.example.yml")
        self.assertTrue(settings.reload_if_changed())
        self.assertTrue(settings.default_model().startswith("bedrock/"))
        self.assertIn("aws_session_token", settings.litellm_args())

    def test_env_variable_in_yaml_file(self):
        """An unquoted ${VAR} in YAML is read as text and expanded."""
        self.path.write_text("session_token: ${SL_TOKEN}\n", encoding="utf-8")
        settings = BedrockSettings(self.path)
        with unittest.mock.patch.dict("os.environ", {"SL_TOKEN": "tok"}):
            settings.reload_if_changed()
            self.assertEqual(settings.litellm_args(), {"aws_session_token": "tok"})

    def test_agent_without_any_model_is_rejected(self):
        """An agent with no model and no default model cannot be built."""
        folder = self.path.parent
        (folder / "a.json").write_text(json.dumps({"name": "a"}), encoding="utf-8")
        (folder / "a-prompt.md").write_text("Hi", encoding="utf-8")
        with self.assertRaises(AgentConfigError):
            load_agent(folder / "a.json", "")


if __name__ == "__main__":
    unittest.main()
