"""Math skills: a safe arithmetic calculator that never uses eval()."""
import ast
import operator

from .registry import skill

OPERATORS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
    ast.USub: operator.neg,
    ast.UAdd: operator.pos,
}
MAX_EXPONENT = 100


@skill
def calculate(expression: str) -> dict:
    """Evaluate a basic arithmetic expression such as "(12 + 8) * 3 / 4".

    Supports + - * / // % ** and parentheses.

    Args:
        expression: The arithmetic expression to evaluate.

    Returns:
        A dict with status and the numeric result, or an error message.
    """
    try:
        tree = ast.parse(expression, mode="eval")
        result = _evaluate(tree.body)
    except (SyntaxError, ValueError, ZeroDivisionError, OverflowError) as error:
        return {"status": "error", "error_message": str(error)}
    return {"status": "success", "expression": expression, "result": result}


def _evaluate(node: ast.AST) -> float:
    """Recursively evaluate an AST node, allowing only numbers and arithmetic operators."""
    if isinstance(node, ast.Constant) and type(node.value) in (int, float):
        return node.value
    if isinstance(node, ast.BinOp) and type(node.op) in OPERATORS:
        return _apply_binary(node)
    if isinstance(node, ast.UnaryOp) and type(node.op) in OPERATORS:
        return OPERATORS[type(node.op)](_evaluate(node.operand))
    raise ValueError("Only numbers and + - * / // % ** ( ) are allowed")


def _apply_binary(node: ast.BinOp) -> float:
    """Evaluate a binary operation, refusing huge exponents that would hang the server."""
    left = _evaluate(node.left)
    right = _evaluate(node.right)
    if isinstance(node.op, ast.Pow) and abs(right) > MAX_EXPONENT:
        raise ValueError(f"Exponents above {MAX_EXPONENT} are not allowed")
    return OPERATORS[type(node.op)](left, right)
