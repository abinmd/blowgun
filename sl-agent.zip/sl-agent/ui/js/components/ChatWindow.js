// Chat window: list of messages and the message box.
import { html, useState, useEffect, useRef } from "../lib.js";

/** Left side of the page. */
export function ChatWindow({ state, onSend }) {
  const ready = Boolean(state.sessionId);
  return html`
    <section className="chat">
      <${MessageList} messages=${state.messages} busy=${state.busy} agentInfo=${state.agentInfo} />
      <${Composer} disabled=${state.busy || !ready} onSend=${onSend} />
    </section>
  `;
}

/** Scrollable list of messages; keeps the newest message in view. */
function MessageList({ messages, busy, agentInfo }) {
  const endRef = useRef(null);
  useEffect(() => {
    if (endRef.current) endRef.current.scrollIntoView({ behavior: "smooth" });
  }, [messages, busy]);
  return html`
    <div className="messages">
      ${messages.length === 0 && html`<${EmptyState} agentInfo=${agentInfo} />`}
      ${messages.map((message, index) => html`<${MessageBubble} key=${index} message=${message} />`)}
      ${busy && html`<div className="typing"><span></span><span></span><span></span></div>`}
      <div ref=${endRef}></div>
    </div>
  `;
}

/** Greeting shown before the first message of a chat. */
function EmptyState({ agentInfo }) {
  if (!agentInfo) return html`<div className="empty muted">Starting agent…</div>`;
  return html`
    <div className="empty">
      <h2>${agentInfo.name}</h2>
      <p className="muted">${agentInfo.description}</p>
    </div>
  `;
}

/** One chat bubble; its style depends on the role (user, agent or error). */
function MessageBubble({ message }) {
  return html`<div className=${`bubble bubble-${message.role}`}>${message.text}</div>`;
}

/** Message box: Enter sends, Shift+Enter adds a new line. */
function Composer({ disabled, onSend }) {
  const [text, setText] = useState("");
  const canSend = !disabled && text.trim().length > 0;
  const submit = () => {
    if (!canSend) return;
    onSend(text.trim());
    setText("");
  };
  const onKeyDown = enterSends(submit);
  return html`
    <div className="composer">
      <textarea rows="2" value=${text} placeholder="Type a message…" onChange=${(e) => setText(e.target.value)} onKeyDown=${onKeyDown} />
      <button onClick=${submit} disabled=${!canSend}>Send</button>
    </div>
  `;
}

/** Key handler that calls submit on Enter (without Shift). */
function enterSends(submit) {
  return (event) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      submit();
    }
  };
}
