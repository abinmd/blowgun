"""Application entry point: one FastAPI app serves the API (/api) and the React UI (/).

Run with:  uvicorn app.main:app --reload     (or: python -m app)
"""
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from google.adk.sessions import InMemorySessionService

from . import config
from .action_logger import setup_action_logger
from .agent_loader import load_agents
from .agent_registry import AgentRegistry
from .api import router
from .bedrock import BedrockSettings
from .skills import load_all_skills
from .users import UserStore

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
logger = logging.getLogger("sl_agent")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Start-up: load skills, initialise all agents and load users. Shutdown: close MCP links."""
    log_file = setup_action_logger(config.LOG_DIR)
    logger.info("Skills available: %s", load_all_skills())
    bedrock = _load_bedrock_settings()
    default_model = config.DEFAULT_MODEL or bedrock.default_model()
    registry = AgentRegistry(InMemorySessionService(), bedrock)
    await registry.initialise(load_agents(config.AGENTS_DIR, default_model))
    users = UserStore.from_file(config.USERS_FILE)
    users.apply_known_agents(registry.names())
    app.state.registry = registry
    app.state.users = users
    logger.info("Ready: %d agents, %d users. Action log: %s", len(registry.names()), users.count(), log_file)
    yield
    await registry.close()


def _load_bedrock_settings() -> BedrockSettings:
    """Read config/bedrock.yml, with a clear hint when it does not exist yet."""
    bedrock = BedrockSettings(config.BEDROCK_CONFIG)
    if not bedrock.reload_if_changed():
        logger.warning(
            "No Bedrock config at %s: copy config/bedrock.example.yml to config/bedrock.yml",
            config.BEDROCK_CONFIG,
        )
    return bedrock


def create_app() -> FastAPI:
    """Build the app: API routes first, then the UI as static files at '/'."""
    app = FastAPI(title="SL Agent", lifespan=lifespan)
    app.include_router(router)
    # Mounted last so it only answers paths that are not API routes.
    app.mount("/", StaticFiles(directory=config.UI_DIR, html=True), name="ui")
    return app


app = create_app()
