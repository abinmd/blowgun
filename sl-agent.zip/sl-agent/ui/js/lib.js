// Shared React helpers: the only place that imports React, so components stay short.
import React from "react";
import htm from "htm";

/** Tagged template that turns HTML-like markup into React elements (JSX without a build). */
export const html = htm.bind(React.createElement);

export const { useState, useEffect, useReducer, useRef, useCallback } = React;
