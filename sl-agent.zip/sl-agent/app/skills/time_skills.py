"""Date and time skills."""
from datetime import datetime
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from .registry import skill


@skill
def get_current_time(timezone: str = "UTC") -> dict:
    """Get the current date and time in a timezone.

    Args:
        timezone: IANA timezone name, for example "Asia/Hong_Kong" or "Europe/London".

    Returns:
        A dict with status, the ISO date-time and weekday, or an error message.
    """
    try:
        now = datetime.now(ZoneInfo(timezone))
    except (ZoneInfoNotFoundError, ValueError):
        return {"status": "error", "error_message": f"Unknown timezone '{timezone}'"}
    return {
        "status": "success",
        "timezone": timezone,
        "datetime": now.isoformat(timespec="seconds"),
        "weekday": now.strftime("%A"),
    }
