"""JSON API used by the UI (all routes live under /api).

Every route except /health and /login needs the X-Username header of a user in users.json.
"""
import json
from typing import Annotated, AsyncIterator

from fastapi import APIRouter, Depends, Header, HTTPException, Request
from fastapi.responses import StreamingResponse

from .agent_registry import AgentRegistry, LoadedAgent
from .chat_service import session_exists, start_session, stream_chat
from .schemas import ChatRequest, LoginRequest, SessionRequest
from .users import User, UserStore

router = APIRouter(prefix="/api")


def get_registry(request: Request) -> AgentRegistry:
    """Return the agent registry created at start-up."""
    return request.app.state.registry


def get_users(request: Request) -> UserStore:
    """Return the user store created at start-up."""
    return request.app.state.users


def current_user(
    users: Annotated[UserStore, Depends(get_users)],
    x_username: Annotated[str, Header()] = "",
) -> User:
    """Resolve the logged-in user from the X-Username header, or reject the call."""
    user = users.get(x_username)
    if user is None:
        raise HTTPException(status_code=401, detail="Please log in")
    return user


RegistryDep = Annotated[AgentRegistry, Depends(get_registry)]
UsersDep = Annotated[UserStore, Depends(get_users)]
UserDep = Annotated[User, Depends(current_user)]


def allowed_agent(name: str, user: User, registry: AgentRegistry) -> LoadedAgent:
    """Return the agent if it exists and this user may use it; otherwise raise 403 or 404."""
    if not user.can_use(name):
        raise HTTPException(status_code=403, detail=f"You may not use agent '{name}'")
    loaded = registry.get(name)
    if loaded is None:
        raise HTTPException(status_code=404, detail=f"Agent '{name}' is not available")
    return loaded


@router.get("/health")
def health(registry: RegistryDep) -> dict:
    """Simple health check listing the agents that are ready."""
    return {
        "status": "ok",
        "agents": registry.names(),
        "bedrock_config_loaded": registry.bedrock.is_loaded(),
        "bedrock_region": registry.bedrock.region(),
    }


@router.post("/login")
def login(body: LoginRequest, users: UsersDep) -> dict:
    """Log in with a username listed in users.json (no password, as per the spec)."""
    user = users.get(body.username)
    if user is None:
        raise HTTPException(status_code=401, detail="Unknown user name")
    return user.to_dict()


@router.get("/agents")
def list_agents(user: UserDep, registry: RegistryDep) -> list[dict]:
    """List the agents this user may pick in the drop-down."""
    agents = []
    for name in user.allowed_agents:
        loaded = registry.get(name)
        if loaded:
            agents.append(loaded.summary())
    return agents


@router.get("/agents/{name}")
def agent_details(name: str, user: UserDep, registry: RegistryDep) -> dict:
    """Full details of one agent (model, prompt, skills, MCP servers)."""
    return allowed_agent(name, user, registry).details()


@router.post("/sessions")
async def new_session(body: SessionRequest, user: UserDep, registry: RegistryDep) -> dict:
    """Start a clean chat with an agent; returns the session id, agent details and first event."""
    loaded = allowed_agent(body.agent, user, registry)
    event = await start_session(loaded, user)
    return {"session_id": event["session_id"], "agent": loaded.details(), "event": event}


@router.post("/chat")
async def chat(body: ChatRequest, user: UserDep, registry: RegistryDep) -> StreamingResponse:
    """Send a message; the response streams trace events (one JSON per line) as the agent works."""
    loaded = allowed_agent(body.agent, user, registry)
    registry.refresh_credentials()  # picks up a new session token without a restart
    if not await session_exists(loaded, user, body.session_id):
        raise HTTPException(status_code=404, detail="Session not found, please start a new chat")
    events = stream_chat(loaded, user, body.session_id, body.message)
    return StreamingResponse(_ndjson(events), media_type="application/x-ndjson")


async def _ndjson(events: AsyncIterator[dict]) -> AsyncIterator[str]:
    """Encode trace events as newline-delimited JSON for streaming to the browser."""
    async for event in events:
        yield json.dumps(event, default=str, ensure_ascii=False) + "\n"
