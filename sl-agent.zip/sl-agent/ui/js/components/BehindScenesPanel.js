// Right panel: how the agent is built (model, prompt, skills, MCP servers) and a live trace.
import { html, useEffect, useRef } from "../lib.js";

/** The whole behind-the-scenes panel. */
export function BehindScenesPanel({ agentInfo, sessionId, trace }) {
  return html`
    <aside className="panel">
      <h2 className="panel-title">Behind the scenes</h2>
      ${agentInfo && html`<${AgentDetails} info=${agentInfo} sessionId=${sessionId} />`}
      ${!agentInfo && html`<p className="muted">Choose an agent to begin.</p>`}
      <${TraceList} trace=${trace} />
    </aside>
  `;
}

/** Agent facts: model, session, config file, prompt, skills and MCP servers. */
function AgentDetails({ info, sessionId }) {
  return html`
    <div className="agent-details">
      <section className="panel-section">
        <h3>Agent</h3>
        <dl className="facts">
          <dt>Name</dt><dd>${info.name}</dd>
          <dt>Model</dt><dd>${info.model}</dd>
          <dt>Config</dt><dd>${info.config_file}</dd>
          <dt>Session</dt><dd className="mono">${sessionId}</dd>
        </dl>
        <details><summary>System prompt</summary><pre>${info.instruction}</pre></details>
      </section>
      <${SkillList} skills=${info.skills} missing=${info.missing_skills} />
      <${McpList} servers=${info.mcp_servers} />
    </div>
  `;
}

/** Chips for the agent's skills, plus a warning for skills that are not registered. */
function SkillList({ skills, missing }) {
  return html`
    <section className="panel-section">
      <h3>Skills</h3>
      ${skills.length === 0 && html`<p className="muted">No skills</p>`}
      <div className="chips">${skills.map((name) => html`<span key=${name} className="chip">${name}</span>`)}</div>
      ${missing.length > 0 && html`<p className="warn-text">Unknown skills ignored: ${missing.join(", ")}</p>`}
    </section>
  `;
}

/** List of MCP servers with connection status, target and tools. */
function McpList({ servers }) {
  return html`
    <section className="panel-section">
      <h3>MCP servers</h3>
      ${servers.length === 0 && html`<p className="muted">No MCP servers</p>`}
      ${servers.map((server) => html`<${McpServer} key=${server.name} server=${server} />`)}
    </section>
  `;
}

/** One MCP server card. */
function McpServer({ server }) {
  return html`
    <div className="mcp-card">
      <div className="mcp-head">
        <span className=${`dot dot-${server.status}`}></span>
        <strong>${server.name}</strong>
        <span className="muted">${server.type} · ${server.status}</span>
      </div>
      <div className="mono small">${server.target}</div>
      ${server.error && html`<p className="error-text small">${server.error}</p>`}
      <div className="chips">${server.tools.map((tool) => html`<span key=${tool} className="chip chip-mcp">${tool}</span>`)}</div>
    </div>
  `;
}

/** Live list of trace events for the current session; keeps the newest in view. */
function TraceList({ trace }) {
  const endRef = useRef(null);
  useEffect(() => {
    if (endRef.current) endRef.current.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }, [trace.length]);
  return html`
    <section className="panel-section">
      <h3>Trace</h3>
      <ol className="trace">${trace.map((event, index) => html`<${TraceItem} key=${index} event=${event} />`)}</ol>
      <div ref=${endRef}></div>
    </section>
  `;
}

/** One trace step with a coloured label, time, summary and optional JSON data. */
function TraceItem({ event }) {
  const info = describeEvent(event);
  const data = eventData(event);
  return html`
    <li className=${`trace-item tone-${info.tone}`}>
      <div className="trace-head">
        <span className="badge">${info.label}</span>
        <span className="muted small">${formatTime(event.time)}</span>
      </div>
      <div className="trace-text">${info.text}</div>
      ${data !== undefined && html`<details><summary>data</summary><pre>${JSON.stringify(data, null, 2)}</pre></details>`}
    </li>
  `;
}

/** One describer per event type: returns a label, a colour tone and a one-line summary. */
const DESCRIBERS = {
  session_started: (e) => ({ label: "Session", tone: "info", text: `New session with ${e.agent} (${e.model})` }),
  user_message: (e) => ({ label: "User", tone: "user", text: e.text }),
  model_usage: (e) => ({ label: "LLM call", tone: "llm", text: `${e.prompt_tokens} in / ${e.output_tokens} out tokens` }),
  tool_call: (e) => ({ label: "Tool call", tone: "tool", text: `${e.tool} (${e.source})` }),
  tool_result: (e) => ({ label: "Tool result", tone: "tool", text: `${e.tool} returned` }),
  thought: (e) => ({ label: "Thinking", tone: "llm", text: e.text }),
  agent_message: (e) => ({ label: e.final ? "Final answer" : "Agent", tone: "agent", text: e.text }),
  error: (e) => ({ label: "Error", tone: "error", text: e.message }),
  turn_complete: (e) => ({ label: "Done", tone: "info", text: `Turn finished in ${e.duration_ms} ms` }),
};

/** Describe a trace event; unknown types just show their type name. */
function describeEvent(event) {
  const describe = DESCRIBERS[event.type];
  if (describe) return describe(event);
  return { label: event.type, tone: "info", text: "" };
}

/** JSON payload worth showing for an event (tool arguments or tool result). */
function eventData(event) {
  if (event.type === "tool_call") return event.args;
  if (event.type === "tool_result") return event.result;
  return undefined;
}

/** Show an ISO timestamp as local hh:mm:ss. */
function formatTime(isoTime) {
  if (!isoTime) return "";
  return new Date(isoTime).toLocaleTimeString();
}
