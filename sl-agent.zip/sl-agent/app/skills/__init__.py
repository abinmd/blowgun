"""Skills package. Every module in this folder is imported at start-up so its @skill
functions register themselves. To add a skill, drop a new module here (see time_skills.py).
"""
import importlib
import pkgutil

from .registry import SKILLS, resolve_skills, skill

__all__ = ["SKILLS", "load_all_skills", "resolve_skills", "skill"]


def load_all_skills() -> list[str]:
    """Import every module in this package and return the sorted registered skill names."""
    for module in pkgutil.iter_modules(__path__):
        if module.name != "registry":
            importlib.import_module(f"{__name__}.{module.name}")
    return sorted(SKILLS)
