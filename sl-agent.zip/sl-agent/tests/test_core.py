"""Tests for the parts that need no model: agent loading, users, skills and the action log.

Run with:  python -m unittest discover tests
"""
import json
import tempfile
import unittest
import unittest.mock
from pathlib import Path

from app import config
from app.action_logger import log_action, setup_action_logger
from app.agent_loader import AgentConfigError, load_agent, load_agents
from app.skills import load_all_skills, resolve_skills
from app.skills.math_skills import calculate
from app.skills.time_skills import get_current_time
from app.users import User, UserStore


def write_agent(folder: Path, stem: str, config_data: dict, prompt: str | None = "Be helpful.") -> Path:
    """Write <stem>.json and (optionally) <stem>-prompt.md into folder; return the config path."""
    config_file = folder / f"{stem}.json"
    config_file.write_text(json.dumps(config_data), encoding="utf-8")
    if prompt is not None:
        (folder / f"{stem}-prompt.md").write_text(prompt, encoding="utf-8")
    return config_file


class AgentLoaderTests(unittest.TestCase):
    """Reading agents from the agents folder."""

    def setUp(self):
        """Give each test an empty temporary agents folder."""
        self._tmp = tempfile.TemporaryDirectory()
        self.folder = Path(self._tmp.name)

    def tearDown(self):
        """Remove the temporary folder."""
        self._tmp.cleanup()

    def test_sample_agents_load(self):
        """The agents shipped in the repo all load with their prompts."""
        specs = load_agents(config.AGENTS_DIR, "test-model")
        names = sorted(spec.name for spec in specs)
        self.assertEqual(names, ["assistant", "file_helper", "math_tutor"])
        self.assertTrue(all(spec.instruction for spec in specs))

    def test_default_model_used_when_missing(self):
        """An agent without 'model' gets the default model."""
        write_agent(self.folder, "a1", {"name": "a1", "description": "d"})
        spec = load_agents(self.folder, "fallback-model")[0]
        self.assertEqual(spec.model, "fallback-model")

    def test_missing_prompt_is_skipped(self):
        """An agent without a -prompt file is skipped, not fatal."""
        write_agent(self.folder, "a1", {"name": "a1"}, prompt=None)
        self.assertEqual(load_agents(self.folder, "m"), [])

    def test_invalid_name_rejected(self):
        """Names must be valid identifiers for ADK."""
        path = write_agent(self.folder, "bad", {"name": "bad name!"})
        with self.assertRaises(AgentConfigError):
            load_agent(path, "m")

    def test_duplicate_names_keep_first(self):
        """Two files with the same agent name: only the first is kept."""
        write_agent(self.folder, "a", {"name": "same"})
        write_agent(self.folder, "b", {"name": "same"})
        self.assertEqual(len(load_agents(self.folder, "m")), 1)

    def test_mcp_validation_and_env_expansion(self):
        """MCP entries are validated and ${VAR} values are expanded."""
        server = {"name": "s", "type": "http", "url": "https://x/${SL_TEST_HOST}"}
        path = write_agent(self.folder, "a", {"name": "a", "mcp_servers": [server]})
        with unittest.mock.patch.dict("os.environ", {"SL_TEST_HOST": "mcp"}):
            spec = load_agent(path, "m")
        self.assertEqual(spec.mcp_servers[0].url, "https://x/mcp")
        bad = write_agent(self.folder, "b", {"name": "b", "mcp_servers": [{"type": "stdio"}]})
        with self.assertRaises(AgentConfigError):
            load_agent(bad, "m")


class UserStoreTests(unittest.TestCase):
    """Users file handling."""

    def test_wildcard_unknown_and_default(self):
        """'*' expands, unknown agents are dropped and a bad default falls back."""
        star = User("admin", "u1", ["*"], "assistant")
        odd = User("bob", "u2", ["math_tutor", "ghost"], "ghost")
        store = UserStore([star, odd])
        store.apply_known_agents(["assistant", "math_tutor"])
        self.assertEqual(star.allowed_agents, ["assistant", "math_tutor"])
        self.assertEqual(odd.allowed_agents, ["math_tutor"])
        self.assertEqual(odd.default_agent, "math_tutor")

    def test_lookup_is_case_insensitive(self):
        """Usernames match regardless of case and spaces."""
        store = UserStore.from_file(config.USERS_FILE)
        self.assertIsNotNone(store.get("  Alice "))
        self.assertIsNone(store.get("nobody"))


class SkillTests(unittest.TestCase):
    """Built-in skills and the registry."""

    def test_registry_finds_skills(self):
        """Registered skills resolve and unknown names are reported."""
        self.assertIn("calculate", load_all_skills())
        found, missing = resolve_skills(["calculate", "nope"])
        self.assertEqual([func.__name__ for func in found], ["calculate"])
        self.assertEqual(missing, ["nope"])

    def test_calculate(self):
        """The calculator handles arithmetic and refuses code."""
        self.assertEqual(calculate("(12 + 8) * 3 / 4")["result"], 15)
        self.assertEqual(calculate("-2 ** 3")["result"], -8)
        self.assertEqual(calculate("__import__('os')")["status"], "error")
        self.assertEqual(calculate("1/0")["status"], "error")
        self.assertEqual(calculate("2 ** 1000")["status"], "error")

    def test_current_time(self):
        """Valid timezones work; unknown ones return an error."""
        self.assertEqual(get_current_time("Asia/Hong_Kong")["status"], "success")
        self.assertEqual(get_current_time("Mars/Base")["status"], "error")


class ActionLogTests(unittest.TestCase):
    """The agent action log."""

    def test_writes_json_lines(self):
        """Each action becomes one JSON line in agent_actions.log."""
        with tempfile.TemporaryDirectory() as tmp:
            log_file = setup_action_logger(Path(tmp))
            log_action({"type": "tool_call", "tool": "calculate"})
            line = log_file.read_text(encoding="utf-8").strip()
        self.assertEqual(json.loads(line)["tool"], "calculate")


if __name__ == "__main__":
    unittest.main()
