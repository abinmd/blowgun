// Chat page layout: top bar, chat window on the left, behind-the-scenes panel on the right.
import { html } from "../lib.js";
import { useAgentChat } from "../store.js";
import { TopBar } from "./TopBar.js";
import { ChatWindow } from "./ChatWindow.js";
import { BehindScenesPanel } from "./BehindScenesPanel.js";

/** Main page shown after login. */
export function ChatPage({ user, onLogout }) {
  const { state, selectAgent, send } = useAgentChat(user);
  return html`
    <div className="app-shell">
      <${TopBar}
        user=${user}
        agents=${state.agents}
        agentName=${state.agentName}
        onSelect=${selectAgent}
        onLogout=${onLogout}
      />
      <main className="workspace">
        <${ChatWindow} state=${state} onSend=${send} />
        <${BehindScenesPanel} agentInfo=${state.agentInfo} sessionId=${state.sessionId} trace=${state.trace} />
      </main>
    </div>
  `;
}
