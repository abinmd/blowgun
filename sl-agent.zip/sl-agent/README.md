# SL Agent

A small, easy-to-maintain app for building and chatting with AI agents.
One **FastAPI** server runs **Google ADK** agents on **AWS Bedrock** models, serves the JSON API under `/api`
and serves the **React** UI at `/`. The UI needs no build step and no Node.js.

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp config/bedrock.example.yml config/bedrock.yml     # then fill in your AWS credentials
python -m app                                         # or: uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000 and sign in as `admin`, `alice` or `bob`.
The `file_helper` sample agent uses an MCP server started with `npx`, so it needs Node.js.
If `npx` is missing, that agent still starts and the panel shows the MCP server as `error`.

## AWS Bedrock config

Credentials and the default model live in `config/bedrock.yml`. Git ignores this file;
`config/bedrock.example.yml` is the commented template to copy.

```yaml
region: us-east-1
access_key_id: ASIA...
secret_access_key: ...
session_token: ...
profile: ""
default_model: bedrock/global.anthropic.claude-sonnet-5
```

- **Session token refresh:** the file is re-read before each chat turn if it has changed.
  When the temporary credentials expire, paste the new access key, secret and session token,
  and the next message uses them. No restart is needed. An expired token shows a clear hint
  in the chat.
- **Values from the environment:** any value can be `${ENV_VAR}`, for example
  `session_token: ${AWS_SESSION_TOKEN}`.
- **Other ways to sign in:** leave the three key fields empty to use `profile` (from `~/.aws`)
  or the normal AWS credential chain (environment variables, IAM role).
- **Model IDs:** use the Bedrock model or inference profile ID with a `bedrock/` prefix. The
  prefix must suit your region (`us.`, `eu.`, `apac.`, `jp.`, `global.`). Copy the exact ID
  from the Bedrock console for your account and region.
- **Per-agent model:** an agent can override the default with `"model"` in its JSON.
  A name without `bedrock/` (e.g. `gemini-2.5-flash`) still goes to Gemini.
- **Security:** the credentials are never sent to the UI or written to the action log.
  Keep the file private (`chmod 600 config/bedrock.yml`).

## Folder layout

```
agents/                    one agent = <name>.json + <name>-prompt.md
  assistant.json
  assistant-prompt.md
  ...
users.json                 users, their allowed agents and default agent
config/bedrock.yml        AWS region, credentials, default model (git-ignored)
app/
  main.py                  start-up: load skills, agents, users; serve API + UI
  api.py                   /api routes
  agent_loader.py          reads the agents folder
  agent_registry.py        builds every ADK agent + runner at start-up
  bedrock.py / models.py   Bedrock settings and model creation (via LiteLLM)
  chat_service.py          runs a chat turn, turns ADK events into trace events
  mcp_tools.py             MCP connections (stdio / http / sse)
  skills/                  Python skills (tools) agents can use
  users.py                 users.json handling
  action_logger.py         agent action log (logs/agent_actions.log)
ui/                        React UI (index.html, styles.css, js/)
workspace/                 sandbox folder for the file_helper agent
tests/  scripts/           tests and coding-rule checks
```

## Add an agent

1. Create `agents/<name>.json`:

```json
{
  "name": "travel_helper",
  "description": "Shown in the agent drop-down.",
  "model": "bedrock/us.anthropic.claude-opus-5",
  "skills": ["get_current_time"],
  "mcp_servers": []
}
```

2. Create `agents/<name>-prompt.md` with the system prompt (role and task).
3. Add the agent to users in `users.json`, then restart. All agents are initialised at start-up.

Rules: the name may use only letters, digits and `_`. `model` is optional and defaults to
`default_model` in `config/bedrock.yml`. A broken agent file is logged and skipped; the other agents still load.

### MCP servers

```json
"mcp_servers": [
  { "name": "filesystem", "type": "stdio", "command": "npx",
    "args": ["-y", "@modelcontextprotocol/server-filesystem", "./workspace"] },
  { "name": "my_api", "type": "http", "url": "https://example.com/mcp",
    "headers": { "Authorization": "Bearer ${MY_API_TOKEN}" } }
]
```

`type` is `stdio`, `http` (streamable HTTP) or `sse`. `${VAR}` values are read from the
environment, which keeps secrets out of the config. Add `"tool_filter": ["tool_a"]` to expose
only some tools. Stdio servers start in the project folder. At start-up each server is
contacted once, and the panel shows its status and tools. A server that does not answer is
left out, so the agent still works with its other tools.

## Add a skill

Create a file in `app/skills/` (it is picked up automatically):

```python
from .registry import skill

@skill
def word_count(text: str) -> dict:
    """Count the words in a text.

    Args:
        text: The text to count.
    """
    return {"status": "success", "words": len(text.split())}
```

Then list `"word_count"` in an agent's `skills`. ADK reads the type hints and the docstring
to describe the tool to the model, so keep them clear.

## Users

`users.json` lists `username`, `user_id`, `allowed_agents` and `default_agent`.
`"allowed_agents": ["*"]` gives a user every agent. Unknown agents are ignored, and an invalid
default falls back to the first allowed agent. Login is username-only, as in the spec; add
real authentication before exposing the app outside a trusted network.

## UI

- **Login page**: enter a username from `users.json`.
- **Top bar**: an agent drop-down showing the user's allowed agents. Choosing an agent (or
  pressing **New chat**) clears the chat and starts a fresh session.
- **Chat window** on the left.
- **Behind the scenes** panel on the right: model, config file, system prompt, skills,
  MCP servers (status, command or URL, tools), and a live trace of each step. The trace
  covers LLM calls with token counts, tool calls with arguments, tool results, thinking,
  the final answer, errors and timing.

## Logging

Every agent action (session start, user message, LLM call, tool call or result, answer,
error, turn complete) is written as one JSON line to `logs/agent_actions.log` with time,
user, agent and session id. The file rotates at 5 MB and 5 files are kept.

## API

| Method | Path | Purpose |
|---|---|---|
| GET  | `/api/health` | status, ready agents, whether the Bedrock config is loaded |
| POST | `/api/login` | `{username}` returns the user |
| GET  | `/api/agents` | agents allowed for the user |
| GET  | `/api/agents/{name}` | agent details |
| POST | `/api/sessions` | `{agent}` starts a fresh chat |
| POST | `/api/chat` | `{agent, session_id, message}` streams trace events (NDJSON) |

All routes except health and login need the `X-Username` header.
Sessions are kept in memory, so they reset when the server restarts.

## Coding rules and checks

Each function has a comment or docstring, is at most 20 lines, and uses plain `if`/`switch`
instead of complex expressions. Check with:

```bash
python -m unittest discover tests
python scripts/check_style.py         # Python: docstrings + 20-line limit
node scripts/check_js_style.mjs       # UI: comments + 20-line limit (optional, needs Node)
```
