// Chat page state: one reducer, so every state change is in one place and easy to follow.
import { useReducer, useEffect, useCallback } from "./lib.js";
import { listAgents, startSession, streamChat } from "./api.js";

export const initialState = {
  agents: [],
  agentName: "",
  agentInfo: null,
  sessionId: "",
  messages: [],
  trace: [],
  busy: false,
};

/** Apply one action to the chat state (agent/session actions here, chat-turn actions below). */
export function chatReducer(state, action) {
  switch (action.type) {
    case "AGENTS_LOADED":
      return { ...state, agents: action.agents };
    case "SESSION_STARTING":
      return { ...initialState, agents: state.agents, agentName: action.agentName, busy: true };
    case "SESSION_STARTED":
      return applySessionStarted(state, action);
    default:
      return turnReducer(state, action);
  }
}

/** Apply actions that happen during a chat turn: messages, trace events, errors. */
function turnReducer(state, action) {
  switch (action.type) {
    case "USER_MESSAGE":
      return { ...state, busy: true, messages: [...state.messages, { role: "user", text: action.text }] };
    case "TRACE":
      return forSession(state, action.event.session_id, { trace: [...state.trace, action.event] });
    case "MESSAGE":
      return forSession(state, action.sessionId, { messages: [...state.messages, action.message] });
    case "TURN_DONE":
      return forSession(state, action.sessionId, { busy: false });
    case "FAILED":
      return { ...state, busy: false, messages: [...state.messages, { role: "error", text: action.message }] };
    default:
      return state;
  }
}

/** Accept a started session only if the user has not switched to another agent meanwhile. */
function applySessionStarted(state, action) {
  if (action.agentName !== state.agentName) return state;
  return { ...state, sessionId: action.sessionId, agentInfo: action.agentInfo, trace: [action.event], busy: false };
}

/** Apply changes only when they belong to the current session (ignores late events). */
function forSession(state, sessionId, changes) {
  if (sessionId !== state.sessionId) return state;
  return { ...state, ...changes };
}

/** Route one streamed trace event: always to the panel, final answers and errors to the chat. */
function handleStreamEvent(event, dispatch) {
  dispatch({ type: "TRACE", event });
  switch (event.type) {
    case "agent_message":
      if (event.final) {
        dispatch({ type: "MESSAGE", sessionId: event.session_id, message: { role: "agent", text: event.text } });
      }
      break;
    case "error":
      dispatch({ type: "MESSAGE", sessionId: event.session_id, message: { role: "error", text: event.message } });
      break;
    default:
      break;
  }
}

/** Pick the agent to open first: the user's default agent, else the first in the list. */
function pickStartAgent(user, agents) {
  if (agents.some((agent) => agent.name === user.default_agent)) return user.default_agent;
  if (agents.length > 0) return agents[0].name;
  return "";
}

/** Load the user's agents, then open the start agent. */
async function loadAgents(user, dispatch) {
  try {
    const agents = await listAgents();
    dispatch({ type: "AGENTS_LOADED", agents });
    const name = pickStartAgent(user, agents);
    if (name) await openAgent(name, dispatch);
  } catch (error) {
    dispatch({ type: "FAILED", message: error.message });
  }
}

/** Clear the chat and start a new session with the chosen agent. */
async function openAgent(agentName, dispatch) {
  dispatch({ type: "SESSION_STARTING", agentName });
  try {
    const result = await startSession(agentName);
    const info = { agentName, sessionId: result.session_id, agentInfo: result.agent, event: result.event };
    dispatch({ type: "SESSION_STARTED", ...info });
  } catch (error) {
    dispatch({ type: "FAILED", message: error.message });
  }
}

/** Send a message and feed every streamed trace event into the state. */
async function sendMessage(state, text, dispatch) {
  dispatch({ type: "USER_MESSAGE", text });
  const body = { agent: state.agentName, session_id: state.sessionId, message: text };
  try {
    await streamChat(body, (event) => handleStreamEvent(event, dispatch));
    dispatch({ type: "TURN_DONE", sessionId: state.sessionId });
  } catch (error) {
    dispatch({ type: "FAILED", message: error.message });
  }
}

/** Hook for the chat page: the state plus two actions (choose agent, send message). */
export function useAgentChat(user) {
  const [state, dispatch] = useReducer(chatReducer, initialState);
  useEffect(() => {
    loadAgents(user, dispatch);
  }, [user]);
  const selectAgent = useCallback((name) => openAgent(name, dispatch), []);
  const send = useCallback((text) => sendMessage(state, text, dispatch), [state]);
  return { state, selectAgent, send };
}
