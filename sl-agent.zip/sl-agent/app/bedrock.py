"""AWS Bedrock settings, read from config/bedrock.yml.

The file holds the region, the AWS credentials (access key, secret key, session token) and the
default model. It is re-read whenever it changes on disk, so a new session token can be pasted
in while the app is running, without a restart.
"""
import logging
import os
from pathlib import Path

import yaml

logger = logging.getLogger(__name__)

BEDROCK_PREFIX = "bedrock/"

# Config file key -> argument name that LiteLLM's Bedrock connector expects.
CREDENTIAL_FIELDS = {
    "region": "aws_region_name",
    "access_key_id": "aws_access_key_id",
    "secret_access_key": "aws_secret_access_key",
    "session_token": "aws_session_token",
    "profile": "aws_profile_name",
}


class BedrockSettings:
    """Holds the Bedrock config and notices when the file is edited."""

    def __init__(self, path: Path):
        """Remember the config path; call reload_if_changed() to read it."""
        self.path = path
        self._data: dict = {}
        self._mtime: float | None = None

    def is_loaded(self) -> bool:
        """True when a config file has been read successfully."""
        return bool(self._data)

    def reload_if_changed(self) -> bool:
        """Re-read the file if it is new or was edited; return True when settings changed."""
        mtime = _modified_time(self.path)
        if mtime is None or mtime == self._mtime:
            return False
        data = _read_config(self.path)
        if data is None:
            return False  # keep the previous settings while the file is invalid
        self._data, self._mtime = data, mtime
        logger.info("Loaded Bedrock settings from %s (region %s)", self.path, self.region())
        return True

    def region(self) -> str:
        """AWS region, e.g. us-east-1."""
        return _value(self._data, "region")

    def default_model(self) -> str:
        """Model used by agents that do not set one, e.g. bedrock/global.anthropic.claude-sonnet-5."""
        return _value(self._data, "default_model")

    def litellm_args(self) -> dict[str, str]:
        """Credentials as LiteLLM arguments; empty values are left out (AWS default chain is used)."""
        args = {}
        for key, arg_name in CREDENTIAL_FIELDS.items():
            value = _value(self._data, key)
            if value:
                args[arg_name] = value
        return args


def _modified_time(path: Path) -> float | None:
    """Last-modified time of the file, or None when it does not exist."""
    try:
        return path.stat().st_mtime
    except FileNotFoundError:
        return None


def _read_config(path: Path) -> dict | None:
    """Parse the YAML config; log and return None when it is not a valid mapping."""
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError) as error:
        logger.error("Cannot read Bedrock config %s: %s", path, error)
        return None
    if not isinstance(data, dict):
        logger.error("Bedrock config %s must contain key: value settings", path)
        return None
    return data


def _value(data: dict, key: str) -> str:
    """Read a setting, expanding ${VAR}; a variable that is not set counts as empty."""
    value = os.path.expandvars(str(data.get(key) or "")).strip()
    if "${" in value:
        logger.warning("Bedrock setting '%s' uses an environment variable that is not set", key)
        return ""
    return value
