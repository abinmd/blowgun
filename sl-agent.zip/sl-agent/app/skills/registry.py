"""Skill registry. A skill is a plain Python function that an agent can call as a tool.

ADK reads the function name, type hints and docstring to describe the tool to the model,
so every skill needs clear type hints and a docstring that explains its arguments.
"""
from typing import Callable

SKILLS: dict[str, Callable] = {}


def skill(func: Callable) -> Callable:
    """Decorator that registers a function as a skill under its own function name."""
    SKILLS[func.__name__] = func
    return func


def resolve_skills(names: list[str]) -> tuple[list[Callable], list[str]]:
    """Return (functions found, names not registered) for an agent's skill list."""
    found = [SKILLS[name] for name in names if name in SKILLS]
    missing = [name for name in names if name not in SKILLS]
    return found, missing
