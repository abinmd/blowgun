"""Request bodies accepted by the API."""
from pydantic import BaseModel, Field


class LoginRequest(BaseModel):
    """Login with a username from users.json."""

    username: str = Field(min_length=1, max_length=100)


class SessionRequest(BaseModel):
    """Start a new (empty) chat with an agent."""

    agent: str


class ChatRequest(BaseModel):
    """Send one message to an agent inside an existing session."""

    agent: str
    session_id: str
    message: str = Field(min_length=1, max_length=20_000)
