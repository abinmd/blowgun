"""Application settings and well-known folder paths (override any of them with env vars)."""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

try:
    from dotenv import load_dotenv

    load_dotenv(BASE_DIR / ".env")
except ImportError:  # python-dotenv is optional; plain environment variables still work
    pass

AGENTS_DIR = Path(os.getenv("AGENTS_DIR", str(BASE_DIR / "agents")))
USERS_FILE = Path(os.getenv("USERS_FILE", str(BASE_DIR / "users.json")))
LOG_DIR = Path(os.getenv("LOG_DIR", str(BASE_DIR / "logs")))
UI_DIR = BASE_DIR / "ui"
BEDROCK_CONFIG = Path(os.getenv("BEDROCK_CONFIG", str(BASE_DIR / "config" / "bedrock.yml")))
# Empty means: use "default_model" from config/bedrock.yml.
DEFAULT_MODEL = os.getenv("DEFAULT_MODEL", "")
MCP_TIMEOUT_SECONDS = float(os.getenv("MCP_TIMEOUT_SECONDS", "30"))
