// App root: shows the login page until a user logs in, then the chat page.
import { createRoot } from "react-dom/client";
import { html, useState } from "./lib.js";
import { setApiUser } from "./api.js";
import { LoginPage } from "./components/LoginPage.js";
import { ChatPage } from "./components/ChatPage.js";

const STORAGE_KEY = "sl-agent-user";

/** Read the remembered user for this browser tab (null when none or storage is blocked). */
function loadSavedUser() {
  try {
    const saved = JSON.parse(sessionStorage.getItem(STORAGE_KEY) || "null");
    if (saved) setApiUser(saved.username);
    return saved;
  } catch {
    return null;
  }
}

/** Remember (or forget) the logged-in user so a page reload keeps the login. */
function saveUser(user) {
  try {
    if (user) sessionStorage.setItem(STORAGE_KEY, JSON.stringify(user));
    else sessionStorage.removeItem(STORAGE_KEY);
  } catch {
    // Storage not available: the login simply lasts until the page reloads.
  }
}

/** Top-level component that switches between the login page and the chat page. */
function App() {
  const [user, setUser] = useState(loadSavedUser);
  const changeUser = (next) => {
    setApiUser(next ? next.username : "");
    saveUser(next);
    setUser(next);
  };
  if (!user) return html`<${LoginPage} onLogin=${changeUser} />`;
  return html`<${ChatPage} user=${user} onLogout=${() => changeUser(null)} />`;
}

createRoot(document.getElementById("root")).render(html`<${App} />`);
