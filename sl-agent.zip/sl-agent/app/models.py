"""Turn a model name from an agent config into something ADK can run.

"bedrock/<model or inference profile id>"  -> AWS Bedrock through LiteLLM, using config/bedrock.yml
any other name (e.g. "gemini-2.5-flash")    -> passed to ADK unchanged (Gemini)
"""
from google.adk.models.lite_llm import LiteLlm

from .bedrock import BEDROCK_PREFIX, BedrockSettings


def build_model(model_name: str, bedrock: BedrockSettings):
    """Return a LiteLlm model with the Bedrock credentials, or the plain model name."""
    if model_name.startswith(BEDROCK_PREFIX):
        return LiteLlm(model=model_name, **bedrock.litellm_args())
    return model_name
