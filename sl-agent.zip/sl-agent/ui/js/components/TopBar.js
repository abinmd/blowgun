// Top bar: app name, agent drop-down (choosing an agent starts a fresh chat), user and logout.
import { html } from "../lib.js";

/** Header shown above the chat and the panel. */
export function TopBar({ user, agents, agentName, onSelect, onLogout }) {
  return html`
    <header className="top-bar">
      <div className="brand"><span className="brand-mark small">SL</span> SL Agent</div>
      <${AgentPicker} agents=${agents} agentName=${agentName} onSelect=${onSelect} />
      <div className="user-box">
        <span>${user.username} <span className="muted">· ${user.user_id}</span></span>
        <button className="ghost" onClick=${onLogout}>Log out</button>
      </div>
    </header>
  `;
}

/** Drop-down of allowed agents plus a "New chat" button that restarts the current agent. */
function AgentPicker({ agents, agentName, onSelect }) {
  const current = agents.find((agent) => agent.name === agentName);
  return html`
    <div className="agent-picker">
      <label htmlFor="agent-select">Agent</label>
      <select id="agent-select" value=${agentName} onChange=${(e) => onSelect(e.target.value)}>
        ${agents.map((agent) => html`<option key=${agent.name} value=${agent.name}>${agent.name}</option>`)}
      </select>
      <button className="ghost" disabled=${!agentName} onClick=${() => onSelect(agentName)}>New chat</button>
      ${current && html`<span className="muted agent-desc">${current.description}</span>`}
    </div>
  `;
}
