# Welcome

This folder is the sandbox for the `file_helper` agent. It reaches these files through
the MCP filesystem server configured in `agents/file_helper.json`.

Try asking the agent: "What files are in the workspace?" or "Summarise welcome.md".
