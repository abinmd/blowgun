"""Agent action log: every step an agent takes is written as one JSON line.

The file is logs/agent_actions.log (rotated at 5 MB, 5 files kept). Each line holds the
time, user, agent, session and what happened (message, tool call, tool result, error...).
"""
import json
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path

_action_logger = logging.getLogger("agent_actions")


def setup_action_logger(log_dir: Path) -> Path:
    """Create the log folder, attach a rotating file handler and return the log file path."""
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "agent_actions.log"
    handler = RotatingFileHandler(log_file, maxBytes=5_000_000, backupCount=5, encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(message)s"))
    _action_logger.handlers = [handler]
    _action_logger.setLevel(logging.INFO)
    _action_logger.propagate = False  # keep the JSON lines out of the console log
    return log_file


def log_action(event: dict) -> None:
    """Write one agent action (already holding time, user, agent and session) to the log."""
    _action_logger.info(json.dumps(event, default=str, ensure_ascii=False))
