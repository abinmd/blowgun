"""Create ADK MCP toolsets from agent config and check that each server is reachable."""
import asyncio
import logging

from google.adk.tools.mcp_tool.mcp_session_manager import (
    SseConnectionParams,
    StdioConnectionParams,
    StreamableHTTPConnectionParams,
)
from mcp import StdioServerParameters
from mcp.client.stdio import get_default_environment

try:  # newer ADK 1.x versions export McpToolset
    from google.adk.tools.mcp_tool import McpToolset
except ImportError:  # older ADK 1.x versions only have MCPToolset
    from google.adk.tools.mcp_tool.mcp_toolset import MCPToolset as McpToolset

from . import config
from .agent_loader import McpServerSpec

logger = logging.getLogger(__name__)


def build_toolset(server: McpServerSpec) -> McpToolset:
    """Create an ADK toolset that exposes the MCP server's tools to an agent."""
    return McpToolset(connection_params=_connection_params(server), tool_filter=server.tool_filter)


def _connection_params(server: McpServerSpec):
    """Pick the ADK connection parameters that match the server type."""
    timeout = config.MCP_TIMEOUT_SECONDS
    match server.type:
        case "stdio":
            return StdioConnectionParams(server_params=_stdio_params(server), timeout=timeout)
        case "http":
            return StreamableHTTPConnectionParams(url=server.url, headers=server.headers, timeout=timeout)
        case "sse":
            return SseConnectionParams(url=server.url, headers=server.headers, timeout=timeout)
    raise ValueError(f"Unsupported MCP type '{server.type}'")


def _stdio_params(server: McpServerSpec) -> StdioServerParameters:
    """Build the command for a local MCP server; it starts in the project folder."""
    # Start from MCP's safe default environment (PATH etc.), then add the configured values.
    env = {**get_default_environment(), **server.env}
    return StdioServerParameters(
        command=server.command, args=server.args, env=env, cwd=str(config.BASE_DIR)
    )


async def probe_toolset(server: McpServerSpec, toolset: McpToolset) -> dict:
    """Connect once and list the tool names, so the UI can show live MCP connection details."""
    status = {"name": server.name, "type": server.type, "target": server.target()}
    try:
        tools = await asyncio.wait_for(toolset.get_tools(), timeout=config.MCP_TIMEOUT_SECONDS)
    except Exception as error:  # any connection problem is reported, never fatal
        message = str(error) or type(error).__name__
        logger.warning("MCP server %s is not reachable: %s", server.name, message)
        return {**status, "status": "error", "error": message, "tools": []}
    return {**status, "status": "connected", "error": "", "tools": [tool.name for tool in tools]}
