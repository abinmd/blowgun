"""Initialise every agent at start-up and keep a ready-to-use ADK runner for each one."""
import logging
from dataclasses import dataclass, field

from google.adk.agents import Agent
from google.adk.runners import Runner
from google.adk.sessions import BaseSessionService

from .agent_loader import AgentSpec
from .bedrock import BedrockSettings
from .mcp_tools import build_toolset, probe_toolset
from .models import build_model
from .skills import resolve_skills

logger = logging.getLogger(__name__)


@dataclass
class LoadedAgent:
    """An initialised agent: its spec, its runner and the tools it really has."""

    spec: AgentSpec
    runner: Runner
    skills: list[str]
    missing_skills: list[str]
    mcp_servers: list[dict]
    toolsets: list = field(default_factory=list)

    def tool_source(self, tool_name: str) -> str:
        """Tell whether a tool is a local skill or comes from an MCP server (shown in the trace)."""
        if tool_name in self.skills:
            return "skill"
        for server in self.mcp_servers:
            if tool_name in server["tools"]:
                return f"mcp:{server['name']}"
        return "tool"

    def summary(self) -> dict:
        """Short info used by the agent drop-down."""
        return {"name": self.spec.name, "description": self.spec.description}

    def details(self) -> dict:
        """Full info used by the behind-the-scenes panel."""
        return {
            **self.summary(),
            "model": self.spec.model,
            "config_file": self.spec.config_file,
            "instruction": self.spec.instruction,
            "skills": self.skills,
            "missing_skills": self.missing_skills,
            "mcp_servers": self.mcp_servers,
        }


class AgentRegistry:
    """Holds every initialised agent by name."""

    def __init__(self, session_service: BaseSessionService, bedrock: BedrockSettings):
        """All agents share one session service (chat history) and one Bedrock config."""
        self.session_service = session_service
        self.bedrock = bedrock
        self._agents: dict[str, LoadedAgent] = {}

    async def initialise(self, specs: list[AgentSpec]) -> None:
        """Build every agent; one that fails is logged and skipped so the others still work."""
        # Built one after another (not in parallel) so MCP connections are opened and
        # closed by the same task, which the MCP client library requires.
        for spec in specs:
            try:
                self._agents[spec.name] = await self._build(spec)
            except Exception as error:
                logger.error("Agent %s failed to initialise: %s", spec.name, error)
                continue
            logger.info("Agent ready: %s (%s)", spec.name, spec.model)

    def refresh_credentials(self) -> bool:
        """If config/bedrock.yml was edited, give every agent a model with the new credentials."""
        if not self.bedrock.reload_if_changed():
            return False
        for loaded in self._agents.values():
            loaded.runner.agent.model = build_model(loaded.spec.model, self.bedrock)
        logger.info("Bedrock settings changed: models refreshed for %d agents", len(self._agents))
        return True

    def get(self, name: str) -> LoadedAgent | None:
        """Return the agent with this name, or None."""
        return self._agents.get(name)

    def names(self) -> list[str]:
        """Names of all agents that initialised successfully."""
        return list(self._agents)

    async def close(self) -> None:
        """Close every open MCP connection (called on shutdown)."""
        for loaded in self._agents.values():
            for toolset in loaded.toolsets:
                await _close_quietly(toolset)

    async def _build(self, spec: AgentSpec) -> LoadedAgent:
        """Create the ADK agent and runner for one spec."""
        skill_funcs, missing = resolve_skills(spec.skills)
        if missing:
            logger.warning("Agent %s: unknown skills ignored %s", spec.name, missing)
        toolsets, mcp_status = await _connect_mcp_servers(spec)
        agent = Agent(
            name=spec.name,
            model=build_model(spec.model, self.bedrock),
            description=spec.description,
            instruction=_static_instruction(spec.instruction),
            tools=[*skill_funcs, *toolsets],
        )
        runner = Runner(agent=agent, app_name=spec.name, session_service=self.session_service)
        skill_names = [func.__name__ for func in skill_funcs]
        return LoadedAgent(spec, runner, skill_names, missing, mcp_status, toolsets)


async def _connect_mcp_servers(spec: AgentSpec) -> tuple[list, list[dict]]:
    """Connect to each MCP server; only servers that answered are given to the agent."""
    working, statuses = [], []
    for server in spec.mcp_servers:
        toolset = build_toolset(server)
        status = await probe_toolset(server, toolset)
        statuses.append(status)
        # A broken server is dropped so the agent can still answer with its other tools.
        if status["status"] == "connected":
            working.append(toolset)
        else:
            await _close_quietly(toolset)
    return working, statuses


def _static_instruction(text: str):
    """Wrap the prompt in a provider so ADK does not treat {braces} in it as state variables."""

    def provider(_context) -> str:
        """Return the agent's system prompt unchanged."""
        return text

    return provider


async def _close_quietly(toolset) -> None:
    """Close an MCP toolset, ignoring errors (used during shutdown and cleanup)."""
    try:
        await toolset.close()
    except Exception as error:
        logger.debug("Ignoring error while closing MCP toolset: %s", error)
