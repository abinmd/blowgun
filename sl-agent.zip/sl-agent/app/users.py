"""Users file: who can log in, which agents each user may use, and their default agent."""
import json
import logging
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

ALL_AGENTS = "*"


@dataclass
class User:
    """One user entry from users.json."""

    username: str
    user_id: str
    allowed_agents: list[str] = field(default_factory=list)
    default_agent: str = ""

    def can_use(self, agent_name: str) -> bool:
        """Return True when this user is allowed to chat with the agent."""
        return agent_name in self.allowed_agents

    def to_dict(self) -> dict:
        """Public view of the user that is returned to the UI."""
        return {
            "username": self.username,
            "user_id": self.user_id,
            "allowed_agents": self.allowed_agents,
            "default_agent": self.default_agent,
        }


class UserStore:
    """Looks users up by username (case-insensitive)."""

    def __init__(self, users: list[User]):
        """Index the given users by lower-case username."""
        self._users = {user.username.lower(): user for user in users}

    @classmethod
    def from_file(cls, path: Path) -> "UserStore":
        """Read users.json, which holds {"users": [ ... ]}."""
        data = json.loads(path.read_text(encoding="utf-8"))
        return cls([_parse_user(item) for item in data.get("users", [])])

    def get(self, username: str) -> User | None:
        """Return the user with this username, or None when unknown."""
        return self._users.get(username.strip().lower())

    def count(self) -> int:
        """Number of users loaded."""
        return len(self._users)

    def apply_known_agents(self, agent_names: list[str]) -> None:
        """Expand '*' and drop unknown agents so every user only sees agents that really exist."""
        for user in self._users.values():
            _fit_user_to_agents(user, agent_names)


def _parse_user(item: dict) -> User:
    """Build a User from one JSON entry; username and user_id are required."""
    if not item.get("username") or not item.get("user_id"):
        raise ValueError(f"each user needs 'username' and 'user_id': {item}")
    return User(
        username=str(item["username"]),
        user_id=str(item["user_id"]),
        allowed_agents=[str(name) for name in item.get("allowed_agents", [])],
        default_agent=str(item.get("default_agent", "")),
    )


def _fit_user_to_agents(user: User, agent_names: list[str]) -> None:
    """Fix one user's allowed agents and default agent against the agents that loaded."""
    if ALL_AGENTS in user.allowed_agents:
        user.allowed_agents = list(agent_names)
    unknown = [name for name in user.allowed_agents if name not in agent_names]
    if unknown:
        logger.warning("User %s: ignoring unknown agents %s", user.username, unknown)
    user.allowed_agents = [name for name in user.allowed_agents if name in agent_names]
    # Fall back to the first allowed agent when the default is missing or not allowed.
    if user.default_agent not in user.allowed_agents:
        user.default_agent = _first_or_empty(user.allowed_agents)


def _first_or_empty(names: list[str]) -> str:
    """Return the first name in the list, or an empty string for an empty list."""
    if names:
        return names[0]
    return ""
