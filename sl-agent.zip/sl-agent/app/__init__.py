"""SL Agent: a small FastAPI + Google ADK app that serves both the API and the UI."""
