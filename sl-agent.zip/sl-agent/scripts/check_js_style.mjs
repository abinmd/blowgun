// Check the UI's top-level JS functions: each needs a /** comment */ above it and at most 20 lines.
// Usage: node scripts/check_js_style.mjs
import { readFileSync, readdirSync, statSync } from "node:fs";
import { join } from "node:path";

const MAX_LINES = 20;

/** List every .js file under a folder. */
function jsFiles(folder) {
  return readdirSync(folder).flatMap((name) => {
    const path = join(folder, name);
    if (statSync(path).isDirectory()) return jsFiles(path);
    return path.endsWith(".js") ? [path] : [];
  });
}

/** Return the rule problems of one file (functions start at column 0 and end with "}" at column 0). */
function checkFile(path) {
  const lines = readFileSync(path, "utf8").split("\n");
  const problems = [];
  lines.forEach((line, index) => {
    const match = line.match(/^(?:export )?(?:async )?function (\w+)/);
    if (!match) return;
    const end = lines.findIndex((other, i) => i > index && other.startsWith("}"));
    const length = end - index + 1;
    if (length > MAX_LINES) problems.push(`${path}:${index + 1} ${match[1]}() has ${length} lines`);
    if (!lines[index - 1] || !lines[index - 1].trim().startsWith("/**")) problems.push(`${path}:${index + 1} ${match[1]}() has no comment`);
  });
  return problems;
}

const problems = jsFiles("ui/js").flatMap(checkFile);
problems.forEach((problem) => console.log(problem));
console.log(`${problems.length} problem(s) found`);
process.exit(problems.length ? 1 : 0);
